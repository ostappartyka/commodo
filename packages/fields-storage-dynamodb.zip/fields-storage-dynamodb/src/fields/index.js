// @flow
import { default as id } from "./id";

export { id };
