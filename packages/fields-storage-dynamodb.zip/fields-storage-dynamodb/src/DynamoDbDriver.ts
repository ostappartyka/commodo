const AWS = require('aws-sdk')
const mdbid = require('mdbid')

AWS.config.update({region: 'eu-central-1'});

const db = new AWS.DynamoDB.DocumentClient();

class DynamoDbDriver {
    database: any;
    tableName: any;

    constructor(database, tableName) {
        this.database = database;
        this.tableName = tableName;
    }

    // // eslint-disable-next-line
    async save({ model, isCreate }) {
        return isCreate ? this.create({ model }) : this.update({ model });
    }

    async create({ model }) {
        if (!model.id) {
            model.id = mdbid();
        }

        const params = {
            TableName: this.tableName,
            Item: {
                ...model
            }
        };

        try {
            await db.put(params).promise();
            return true;
        } catch (e) {
            throw e;
        }
    }

    async update({ model }) {
        const params = {
            TableName: this.tableName,
            Key: { id: model.id },
            ReturnValues: 'ALL_NEW',
            ExpressionAttributeNames: {
                '#name':'name'
            },
            ExpressionAttributeValues: {
                'name': model.name
            },
            UpdateExpression: `SET #name = :name, surnam= :surname`
        };

        try {
            await db.update(params).promise();
            return true;
        } catch (e) {
            throw e;
        }
    }

    // // eslint-disable-next-line
    async delete({ model }) {
        const params = {
            TableName: this.tableName,
            Key: {
                // id: model.id
                id: {
                    "S": model.id
                },
            }
        };

        try {
            await db.delete(params).promise();
            return true;
        } catch (e) {
            throw e;
        }
    }

    // TODO pagination and stuff
    // async find({ model, options }) {
    //     const clonedOptions = { limit: 10, offset: 0, ...options };

    //     MongoDbDriver.__preparePerPageOption(clonedOptions);
    //     MongoDbDriver.__preparePageOption(clonedOptions);
    //     MongoDbDriver.__prepareSearchOption(clonedOptions);

    //     if (this.aggregateTotalCount !== false) {
    //         const $facet = {
    //             results: [{ $skip: clonedOptions.offset }, { $limit: clonedOptions.limit }]
    //         };

    //         if (clonedOptions.sort && Object.keys(clonedOptions.sort).length > 0) {
    //             $facet.results.unshift({ $sort: clonedOptions.sort });
    //         }

    //         if (options.meta !== false) {
    //             $facet.totalCount = [{ $count: "value" }];
    //         }

    //         const pipeline = [
    //             {
    //                 $facet
    //             }
    //         ];

    //         if (clonedOptions.query && Object.keys(clonedOptions.query).length > 0) {
    //             pipeline.unshift({ $match: clonedOptions.query });
    //         }

    //         const [results = {}] = await this.getDatabase()
    //             .collection(this.getCollectionName(model))
    //             .aggregate(pipeline)
    //             .toArray();

    //         if (!Array.isArray(results.results)) {
    //             results.results = [];
    //         }

    //         if (!Array.isArray(results.totalCount)) {
    //             results.totalCount = [];
    //         }

    //         if (options.meta === false) {
    //             return [results.results, {}];
    //         }

    //         return [
    //             results.results,
    //             createPaginationMeta({
    //                 totalCount: results.totalCount[0] ? results.totalCount[0].value : 0,
    //                 page: options.page,
    //                 perPage: options.perPage
    //             })
    //         ];
    //     }

    //     const database = await this.getDatabase()
    //         .collection(this.getCollectionName(model))
    //         .find(clonedOptions.query)
    //         .limit(clonedOptions.limit)
    //         .skip(clonedOptions.offset);

    //     if (clonedOptions.sort && Object.keys(clonedOptions.sort).length > 0) {
    //         database.sort(clonedOptions.sort);
    //     }

    //     const results = await database.toArray();

    //     if (options.meta === false) {
    //         return [results, {}];
    //     }

    //     const totalCount = await this.getDatabase()
    //         .collection(this.getCollectionName(model))
    //         .countDocuments(clonedOptions.query);

    //     const meta = createPaginationMeta({
    //         totalCount,
    //         page: options.page,
    //         perPage: options.perPage
    //     });

    //     return [results, meta];
    // }

    async findOne({ model }) {
        const params = {
            TableName : this.tableName,
            Key: {
                id: model.id
            }
        };

        try {
            const result = await db.get(params).promise();
            return result;
        } catch (e) {
            throw e;
        }
    }



    async find({ query }) {
        // how query should look like
        
        // const test = {
        //     condition: '=',
        //     fields: {
        //         id: 'testId'
        //     }
        // }

        let params = {
            TableName: this.tableName,
            KeyConditionExpression: '',
            ExpressionAttributeNames: '',
            ExpressionAttributeValues: {}
        }

        Object.keys(query.fields).map(field => {
            params.KeyConditionExpression = `#${field} ${query.condition} ${query.fields[field]}`,
            // ExpressionAttributeNames = ,
            params.ExpressionAttributeValues = {
                [`:${field}`]: query.fields[field]
            }
        });

        try {
            console.log("~~~PARAMS~~~", params);
            const result = await db.query(params).promise();

            return result;
        } catch (e) {
            throw e;
        }
    }

    getDatabase() {
        return this.database;
    }
}

const test = new DynamoDbDriver(db, 'test');

async function runTest() {

// test.find({ '$eq': '10', '$lg': 50})

// if(contains 'eq')
// query1 = `${item1} between {item2}`

    await test.find({
       query: {
        condition: '=',
        fields: {
            name: '001'
        }
       }
    });  
};
runTest();

export default DynamoDbDriver;

