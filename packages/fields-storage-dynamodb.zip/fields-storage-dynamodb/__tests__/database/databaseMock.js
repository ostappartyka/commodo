import collectionMock from "./collectionMock";

export default {
    collection: () => {
        return collectionMock;
    }
};
