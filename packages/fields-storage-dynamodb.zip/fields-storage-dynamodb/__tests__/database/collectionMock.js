import find from "./findCursorMock";

export default {
    find: () => find,
    findOne: () => {},
    deleteOne: () => {},
    countDocuments: () => {},
    updateOne: () => {},
    insertOne: () => {},
    aggregate: () => find
};
